package openfoodfacts.github.scrachx.openfood.test

import java.util.*


data class ScreenshotParameter(val locale: Locale, var productCodes: List<String>)