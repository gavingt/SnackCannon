package openfoodfacts.github.scrachx.openfood.features.listeners

/**
 * Created by Lobster on 19.04.18.
 */
fun interface OnRefreshListener {
    fun onRefresh()
}