package openfoodfacts.github.scrachx.openfood.utils

enum class SortType {
    NONE, TIME, BARCODE, BRAND, GRADE, TITLE
}