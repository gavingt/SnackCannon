package openfoodfacts.github.scrachx.openfood.models.eventbus

data class ProductNeedsRefreshEvent(val barcode: String)