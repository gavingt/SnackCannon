package openfoodfacts.github.scrachx.openfood.features.product.view

interface IProductView {
    fun showIngredientsTab(action: ProductViewActivity.ShowIngredientsAction)
}