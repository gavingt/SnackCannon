package openfoodfacts.github.scrachx.openfood.utils

import androidx.core.content.FileProvider

/**
 * Created by prajwalm on 05/04/18.
 */
class GenericFileProvider : FileProvider()