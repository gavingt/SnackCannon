package openfoodfacts.github.scrachx.openfood.utils

enum class ValueState {
    VALID, NOT_VALID, NOT_TESTED
}