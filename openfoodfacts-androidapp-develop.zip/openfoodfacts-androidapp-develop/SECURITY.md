# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| All     | :white_check_mark: |

## Reporting a Vulnerability

Please contact contact@openfoodfacts.org to report any vulnerability. We will try to answer as fast as we can to ensure a speedy fix and a smooth upgrade for all users impacted, 
but remember that the Android contributors are volunteers.
